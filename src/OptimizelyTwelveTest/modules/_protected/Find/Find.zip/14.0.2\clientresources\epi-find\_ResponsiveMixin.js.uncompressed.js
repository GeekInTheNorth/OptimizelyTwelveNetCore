﻿define("epi-find/_ResponsiveMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/_base/Deferred",
    "dojo/on",
    "dojo/Evented",
    "dojo/window",
    "dojo/dom-geometry"

],
function (declare, lang, array, Deferred, on, Evented, window, domGeometry) {
    // This module responsive mode switching

    return declare([Evented], {
        // modes: Object
        //      The available modes list
        modes: null,
        
        // currentWidth: number
        //      The current width in pixels
        currentWidth: null,
        
        // currentMode: Mode
        //      The current mode
        currentMode: null,

        constructor: function (options) {
            this.currentMode = null;
            this.modes = {
                small: { width: 768, name: "small" },
                medium: { width: 1024, name: "medium" },
                full: { width: Infinity, name: "full" }
            };
            if (options && options.modes) {
                declare.safeMixin(this.modes, options.modes);
            }
        },

        startup: function() {
            this.inherited(arguments);
            this._viewResize(); // initial responsive mode detection
        },

        resize: function() {
            this.inherited(arguments);
            this._viewResize();
        },

        getNewSize: function () {
            return this._contentBox || domGeometry.getMarginBox(this.domNode);
        },

        _viewResize: function() {
            var newSize = this.getNewSize();
            if (!newSize.w) {
                return;
            }
            var previousModeWidth = 0;
            this.currentWidth = newSize.w;
            this.objEach(this.modes, function (mode, key) {
                var currentWidth = newSize.w;
                if (mode.width && currentWidth <= mode.width && currentWidth > previousModeWidth) {
                    if (this.currentMode !== mode) {
                        this.currentMode = mode;
                        this.modeChanged(key);
                    }
                }
                previousModeWidth = mode.width; 
            }, this);
        },

        modeChanged: function(modeName) {
            // summary:
            //      A callback function for mode changed notification
            this.emit("modeChanged", modeName);
        },
        
        objEach: function (obj, f, scope) {
            for(var key in obj){
                if(obj.hasOwnProperty(key)){
                    f.call(scope, obj[key], key);
                }
            }
        }
    });
});

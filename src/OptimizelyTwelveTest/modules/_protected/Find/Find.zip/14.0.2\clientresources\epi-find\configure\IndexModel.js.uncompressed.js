define("epi-find/configure/IndexModel", [
    "dojo/_base/declare",
    "dojo/_base/config",
    "dojo/Deferred",
    "dojo/Stateful",
    "epi-saas-base/RetryableXhrWrapper"
],
    function(declare,
        config,
        Deferred,
        Stateful,
        RetryableXhrWrapper) {
        return declare([Stateful], {
            // summary:
            //     Model for Index configuration view.

            // xhrHandler: object
            //      An XHR implementation to use when reading configuration
            xhrHandler: null,

            constructor: function(options) {
                // summary:
                //          Constructs an instance of IndexModel

                declare.safeMixin(this, options);
                this.xhrHandler = this.xhrHandler || new RetryableXhrWrapper();
            },

            clearContentIndex: function () {
                // summary:
                //          Clears content index.
                // returns: dojo/promise/Promise

                return this._clearIndex(true, false);
            },

            clearStats: function () {
                // summary:
                //          Clears statistics.
                // returns: dojo/promise/Promise

                return this._clearIndex(false, true);
            },

            // indexingPluginUrl: String
            //      Url of the EPiServer Find indexing job plugin page
            indexingPluginUrl: "",

            _getTargetUrl: function(/*Boolean*/ clearIndex, /*Boolean*/ clearStats){
                //summary:
                //          Gets url for clear index endpoint
                // clearIndex: Boolean
                //          Flag to indicate whether content index should be cleared
                // clearStats: Boolean
                //          Flag to indicate whether statistics should be cleared
                // returns: String

                return config.find.serviceApiBaseUrl + "_clear?clear_index=" + clearIndex + "&clear_stats=" + clearStats;
            },

            _clearIndex: function(/*Boolean*/ clearIndex, /*Boolean*/ clearStats){
                // summary:
                //          Connects to the endpoint and returns a promise
                // clearIndex: Boolean
                //          Flag to indicate whether content index should be cleared
                // clearStats: Boolean
                //          Flag to indicate whether statistics should be cleared
                // returns: dojo/promise/Promise
                return this.xhrHandler.xhrPost({
                        url: this._getTargetUrl(clearIndex, clearStats),
                        handleAs: "json",
                        xsrfProtection: true
                    }).promise;
            }
        });
    });
define("epi-find/configure/ScheduleModel", [
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/date/locale",

        "dojox/lang/functional",

        "dojo/i18n!./../widget/nls/Schedule"
    ],
function(
        declare,
        lang,
        locale,

        functional,

        i18n
    ) {
    return declare([], {
        i18n: i18n,
        offset: null,
        constructor: function() {
          this.offset = new Date().getTimezoneOffset();
        },
        parseCronSchedule: function(/*String*/ value){
            // summary:
            //      Parses string in cron format (http://en.wikipedia.org/wiki/Cron#Predefined_scheduling_definitions)
            //      into a schedule object with type and parameters. For now it support only those formats that we allow to edit in UI
            if (!value) {
                throw new Error("No schedule value specified");
            }
            if (typeof value !== "string") {
                throw new Error("Schedule value should be a string");
            }

            var weeklyMatch = /(\d+) (\d+) \* \* (\d+)( \*)?/.exec(value);
            if (weeklyMatch) { // weekly
                return {type: "weekly", dayOfTheWeek: parseInt(weeklyMatch[3], 10), time: new Date(0, 0, 0, weeklyMatch[2], weeklyMatch[1])};
            }
            var dailyMatch = /(\d+) (\d+) \* \* \*( \*)?/.exec(value);
            if (dailyMatch) {  // daily
                return {type: "daily", time: new Date(0, 0, 0, dailyMatch[2], dailyMatch[1])};
            }
            return {type: "custom", cronSchedule: value};
        },

        serialiseToCronSchedule: function (/*Object*/ schedule) {
            // summary:
            //      Serialises schedule object as a string in cron format
            if (!schedule) {
                return {};
            }
            if (schedule.type === "weekly") {
                return {cron: "" + schedule.time.getMinutes() + " " + schedule.time.getHours() + " * * " + schedule.dayOfTheWeek};
            }
            else if (schedule.type === "daily") {
                return {cron: "" + schedule.time.getMinutes() + " " + schedule.time.getHours() + " * * *"};
            }
            else if (schedule.type === "custom") {
                return  {cron: schedule.cronSchedule};
            }
        },

        changeScheduleTZ: function(/*Object*/ schedule, /*Int*/ timezoneOffset) {
            //  summary:
            //       Takes schedule object and a timezone offset in minutes and returns a new schedule object without offset.
            if (!schedule || !schedule.time) {
              return {};
            }
            var day;
            var minute = timezoneOffset % 60 + schedule.time.getMinutes();
            var hour = Math.floor(Math.abs(timezoneOffset/60))*this.sign(timezoneOffset) + Math.floor(Math.abs(minute/60))*this.sign(minute) + schedule.time.getHours();
            minute = minute % 60;
            if (typeof(schedule.dayOfTheWeek) !== "undefined") {
              day = parseInt(schedule.dayOfTheWeek, 10);
            }
            if (minute < 0) {
              minute += 60;
              hour --;
            }
            if (hour < 0) {
              hour += 24;
              if (schedule.type === "weekly") {
                day = (day+6) % 7;
              }
            } else if (hour > 24) {
              hour -= 24;
              if (schedule.type === "weekly") {
                day = (day+1) % 7;
              }
            }
            if (schedule.type === "weekly") {
              return {type: schedule.type, dayOfTheWeek: day, time: new Date(0,0,0,hour,minute)};
            } else {
              return {type: schedule.type, time: new Date(0,0,0,hour,minute)};
            }
        },

        sign: function(/*int*/ nbr) {
          return nbr ? nbr<0 ? -1 : 1 : 0;
        },

        getTextDescription: function (value) {
            // summary:
            //      A "static" function that transforms a schedule value in a user friendly string
            if (!value || !value.cron) {
                return this.i18n.noSchedule;
            }
            //Uses timezone offset to change date/time to UTC.
            var schedule = this.parseCronSchedule(value.cron);
            if (schedule.type === "daily") {
                schedule = this.changeScheduleTZ(schedule, -this.offset);
                return lang.replace(this.i18n.dailySchedule, {time: locale.format(schedule.time, { selector: "time"})});
            }
            else if (schedule.type === "weekly") {
                schedule = this.changeScheduleTZ(schedule, -this.offset);
                var weekdaysArray = [i18n.weekdays_monday, i18n.weekdays_tuesday, i18n.weekdays_wednesday, i18n.weekdays_thursday, i18n.weekdays_friday, i18n.weekdays_saturday, i18n.weekdays_sunday];
                return lang.replace(this.i18n.weeklySchedule, {
                    time: locale.format(schedule.time, { selector: "time"}),
                    dayOfTheWeek: weekdaysArray[schedule.dayOfTheWeek - 1]
                });
            }
            return lang.replace(this.i18n.customSchedule, schedule);
        }

    });
});

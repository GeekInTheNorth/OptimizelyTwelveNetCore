define("epi-find/configure/ConnectorModel", [
        "dojo/_base/array",
        "dojo/_base/declare",
        "dojo/_base/config",
        "dojo/_base/lang",
        "dojo/Deferred",
        "dojo/when",
        "dojo/Evented",
        "dojo/Stateful",

        "dojo/store/Memory",
        "dojo/store/Observable",
        "dojo/store/Cache",

        "dijit/Destroyable",

        "dojox/mvc/at",
        "dojox/mvc/EditModelRefController",
        "dojox/mvc/EditStoreRefController",

        "./ScheduleModel",

        "epi-saas-base/mvc/_CommitReturnMixin",
        "epi-saas-base/mvc/_EmptiableRefControllerMixin"
],
    function(array,
             declare,
             config,
             lang,
             Deferred,
             when,
             Evented,
             Stateful,

             MemoryStore,
             Observable,
             Cache,

             Destroyable,

             at,
             EditModelRefController,
             EditStoreRefController,

             ScheduleModel,

             _CommitReturnMixin,
             _EmptiableRefControllerMixin) {

        // module:
        //      epi-find/configure/ConnectorModel

        return declare([Stateful, Destroyable, Evented], {
            // summary:
            //     Model for the site menu for site and language.

            // store: dojo/store/JsonRest
            //      A store that is used for connector data
            store: null,

            // store: dojo/store/JsonRest
            //      A store that is used for connector jobs
            jobStore: null,

            // connectorJobStore: dojo/store/JsonRest
            //      A store that is used for connector jobs
            connectorJobStore: null,

            // connectorJobCachingStore: dojo/store/Cache
            //      A caching store for connector jobs
            connectorJobCachingStore: null,

            // ctrl: dojox/mvc/EditStoreRefController
            //      A controller for binding
            ctrl: null,

            // configController: dojox/mvc/EditModelRefController
            //      A controller for binding "configuration" property of connector
            configController: null,

            // scheduleModel: epi-find/configure/ScheduleModel
            //      Model for the connectors schedule widget
            scheduleModel: null,

            // types: Array
            //      Available connector types
            types: [
                { name: "crawler"},
                { name: "rss_atom"}
            ],

            // channels: Object
            //      Available connector channels
            channels: {
              "crawler" : "system!web",
              "rss_atom": "system!rss_atom"
            },


            // refreshesLeft : Number
            //      Amount of refreshes left for _enqueueRefresh function
            refreshesLeft: 0,

            // refreshQueue: Array
            //      Queue of refreshes for _enqueueRefresh function
            refreshQueue: null,

            // jobStartMaxUpdates: Number
            //      Maximal amount of status update requests when waiting for job to start
            jobStartMaxUpdates: 10,

            // jobStopMaxUpdates: Number
            //      Maximal amount of status update requests when waiting for job to stop
            jobStopMaxUpdates:20,

            postscript: function() {
                this.inherited(arguments);
                this.refreshQueue = [];

                this.store = new Observable(this.store || config.dependencies["epi-find.ConnectorStore"]);
                this.jobStore = this.jobStore || config.dependencies["epi-find.ConnectorJobStore"];

                this.connectorJobCachingStore = new MemoryStore({idProperty: this.jobStore.idProperty});
                this.connectorJobStore = Cache(this.jobStore, this.connectorJobCachingStore);

                var BindingController = declare([EditStoreRefController, _CommitReturnMixin, _EmptiableRefControllerMixin]);
                this.ctrl = new BindingController({
                    store: this.store,
                    emptyModel: new Stateful({
                        type: this.types[0].name,
                        configuration: new Stateful({})
                    })
                });

                this.configController = new EditModelRefController({
                    model: at(this.ctrl, "configuration")
                });

                this.scheduleModel = new ScheduleModel();
            },

            refreshJobCache: function() {
                // summary:
                //      Refreshes connectors job cache.
                //  description:
                //      All connector jobs are stored in cache in order to prevent multiple individual requests
                //      in order to find out job status for each connector.
                return this.connectorJobStore.query();
            },

            getJob: function(connector) {
                // summary:
                //      Returns corresponding connector job for a specified connector
                return this.connectorJobCachingStore.get(this.store.getIdentity(connector));
            },

            startJob: function(connector) {
                // summary:
                //      Starts corresponding connector job for a specified connector
                return when(this.connectorJobStore.start(this.store.getIdentity(connector)), lang.hitch(this, function() {
                    this._enqueueRefresh(connector, "running", this.jobStartMaxUpdates);
                }));
            },

            stopJob: function(connector) {
                // summary:
                //      Stops corresponding connector job for a specified connector

                return when(this.connectorJobStore.stop(this.store.getIdentity(connector)), lang.hitch(this, function() {
                    // Add status refresh to refreshes queue.
                    // Stopping the job usually takes more time then starting,
                    // so we put max 20 attempts to get expected status
                    this._enqueueRefresh(connector, "stopped", this.jobStopMaxUpdates);
                }));
            },

            isActionDisabled: function(connector) {
                // summary:
                //      Returns true if an action was recently triggered, but job status didn't changed accordingly yet.

                var self = this, job = this.getJob(connector),
                    currentStatus = (job && job.mode) ? job.mode : "";
                return array.some(this.refreshQueue, function(item) {
                    return self.store.getIdentity(item.connector) === self.store.getIdentity(connector) && item.status !== currentStatus;
                });
            },

            updateChannel: function() {
              this.ctrl.set("channel", this.channels[this.ctrl.get("type")]);
            },

            _enqueueRefresh: function(/*Object*/ connector, /*String*/ expectedStatus, /*Number*/ maxTries) {

                this.refreshQueue.push({connector: connector, status: expectedStatus});
                var isStarted = this.refreshesLeft > 0;
                this.refreshesLeft = Math.max(this.refreshesLeft, maxTries);
                if (!isStarted) {
                    this._updateStatuses();
                }
            },

            _updateStatuses: function() {

                var nextRefresh = this.refreshQueue.length ? this.refreshQueue[0] : null, // peek top item in the queue
                    self = this;
                if (nextRefresh) {
                    when(this._updateStatus(nextRefresh), function(newStatus) {
                        self.refreshQueue.shift(); // remove top item from queue
                        self.emit("statusChanged", { connector: nextRefresh.connector, status: newStatus });
                        self.store.notify(nextRefresh.connector, self.store.getIdentity(nextRefresh.connector)); // enable button
                        self._updateStatuses();
                    });
                }
                else {
                    this.refreshesLeft = 0;
                }
            },

            _updateStatus : function(data) {
                var self = this, result = new Deferred(), getNewStatus = function () {
                    when(self.refreshJobCache(), function(jobs) {
                        jobs.forEach(function(item) {
                            for (var i=0; i< self.refreshQueue.length; i++) {
                                if (self.store.getIdentity(self.refreshQueue[i].connector) === self.jobStore.getIdentity(item)) {
                                    self.store.notify(self.refreshQueue[i].connector,  self.store.getIdentity(self.refreshQueue[i].connector)); // notify about new status
                                }
                            }
                        });

                        var job = self.getJob(data.connector);
                        var newStatus = job ? job.mode : null;
                        if (newStatus !== data.status && self.refreshesLeft > 0) {
                            self.refreshesLeft--;
                            setTimeout(getNewStatus, 5000); // refresh statuses every 5 seconds
                        }
                        else {
                            result.resolve(newStatus);
                        }
                    });
                };
                getNewStatus();
                return result;
            }

        });
    });

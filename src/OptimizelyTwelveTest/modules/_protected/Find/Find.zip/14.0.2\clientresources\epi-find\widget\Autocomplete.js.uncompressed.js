require({cache:{
'url:epi-find/widget/templates/Autocomplete.html':"<div>\n    <p class=\"epi-view--description\">${i18n.description}</p>\n    <div class=\"error\" data-dojo-attach-point=\"errorNode\"></div>\n    <form data-dojo-attach-point=\"autocompleteForm\"></form>\n    <p class=\"epi-help\">${i18n.help_grid}</p>\n    <div class=\"epi-grid-title-search\" data-dojo-attach-point=\"autocompleteHeader\">\n        <h1>${i18n.header}</h1>\n        <div class=\"epi-search-box\">\n            <input type=\"text\" name=\"query\"\n                   class=\"epi-search-input\"\n                   data-dojo-type=\"dijit/form/TextBox\"\n                   data-dojo-props=\"trim: true, intermediateChanges: true\"\n                   data-dojo-attach-point=\"searchNode\" placeholder=\"${i18n.search}\" />\n        </div>\n    </div>\n    <div id=\"autocompleteGrid\" data-dojo-attach-point=\"autocompleteGrid\" class=\"epi-plain-grid  epi-plain-grid--no-border  epi-grid-max-height--700\"></div>\n</div>"}});
define("epi-find/widget/Autocomplete", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",

    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/_FocusMixin",
    "dijit/form/TextBox",

    "epi-saas-base/Sticker",
    "epi-saas-base/StickyContainer",

    "./_SiblingFocusMixin",
    "./_ActionableMixin",
    "./_DisabledViewMixin",
    "./AutocompleteForm",
    "./AutocompleteGrid",

    "dojo/i18n!./nls/Autocomplete",
    "dojo/text!./templates/Autocomplete.html"

],
    function (
        declare,
        lang,
        when,

        _WidgetBase,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
        _FocusMixin,
        TextBox,

        Sticker,
        StickyContainer,

        _SiblingFocusMixin,
        _ActionableMixin,
        _DisabledViewMixin,
        AutocompleteForm,
        AutocompleteGrid,
        i18n,
        template) {

        // module:
        //      epi-find/widget/Autocomplete

        return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _FocusMixin,
                       _SiblingFocusMixin, _ActionableMixin, _DisabledViewMixin], {
            // summary:
            //     Autocomplete view.

            templateString: template,

            i18n: i18n,

            model: null,

            _form: null,
            _grid: null,

            _searchText: null,

            _searchUpdateTimeout: 400,
            _searchUpdateTimer: null,

            takeAction: function (actions, params) {
                if (params && params.phrases) {
                    this._form.reset();
                    this.model.ctrl.set("query", decodeURIComponent(params.phrases));
                }
                this._grid.refresh();
            },

            postCreate: function () {
                this.inherited(arguments);
                var self = this;

                var form = this._form = new AutocompleteForm({
                    model: this.model,
                    afterSubmit: function(e) {
                        when(self._grid.refresh(), function() {
                            if (e && e.item) {
                                self._grid.select(e.item.id);
                            }
                        });
                    }
                }, this.autocompleteForm);
                this.own(this._form);

                this._grid = new AutocompleteGrid({
                    "class": "epi-plain-grid epi-plain-grid--no-border",
                    store: this.model.store,
                    query: this.model.gridQuery,
                    model: this.model,
                    loadingMessage: i18n.dataLoading,
                    showLoadingMessage: true,
                    onEdit: function (args) {
                        form.edit(args.id);
                    }
                }, this.autocompleteGrid);

                this.own(
                    this._grid,
                    this.model.watch("gridQuery", function(name, oldValue, newValue) {
                        self._grid.set("query", newValue);
                    }),
                    this.searchNode.watch("value", function(name, oldValue, newValue) {
                        self._searchText = newValue;
                        self._delayedReload();
                    })
                );
            },

            _delayedReload: function() {
                //  summary:
                //      Updates grids query with text from the search textbox with delay.
                if (this._searchUpdateTimer) {
                    clearTimeout(this._searchUpdateTimer);
                }
                this._searchUpdateTimer = setTimeout(lang.hitch(this, function () {
                    this._searchUpdateTimer = null;
                    this.model.set("searchText", this._searchText ? "(@ |\"\")" + this._searchText.toLowerCase() + "." : "");
                }), this._searchUpdateTimeout);
            },

            startup: function () {
                this.inherited(arguments);
                var scrollNode = this.scrollNode || this.domNode.parentNode;
                this._form.startup();
                this._grid.set("scrollNode", scrollNode);
                this._grid.startup();

                this.own(
                    new StickyContainer({
                        scrollNode: scrollNode,
                        stickers: [
                            new Sticker({ domNode: this.autocompleteHeader, offset: {top: 0}, limitNode: this._grid.domNode, subscribe: false}),
                            new Sticker({ domNode: this._grid.headerNode, offset: {top: 0}, limitNode: this._grid.domNode, subscribe: false})
                        ]
                    })
                );
            },

            refresh: function () {
                this._grid.refresh();
                this._form.reset();
            }
        });
    });

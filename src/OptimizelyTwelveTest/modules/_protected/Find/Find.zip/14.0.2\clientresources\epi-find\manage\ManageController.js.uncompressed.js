﻿define("epi-find/manage/ManageController", [
    "dojo/_base/declare",
    "dojo/_base/config",

    "../_ControllerBase",
    "./ManageModel",
    "../widget/SwoshContainer",
    "../widget/_SwoshPaneBase",
    "../widget/_ActionableMixin",

    "../widget/Statistics",
    "../widget/Optimization"
],
function(declare, config,
    _ControllerBase,
    ManageModel, SwoshContainer, _SwoshPaneBase, _ActionableMixin,
    StatisticsWidget, OptimizationWidget
) {
    return declare([_ControllerBase, _ActionableMixin], {
        // summary: 
        //      Controller for Manage views.

        model: null,

        swoshContainer: null,

        statistics: null,
        optimization: null,

        startup: function() {
            if (this.isStarted()) {
                return;
            }
            this.inherited(arguments);
            this.model = new ManageModel();
            this.model.init();

            var StatisticsPane = declare([_SwoshPaneBase, StatisticsWidget]),
                OptimizationPane = declare([_SwoshPaneBase, OptimizationWidget]);
                
            this.statistics = new StatisticsPane({
                    model: this.model,
                    name: "statistics",
                    location: "left"
                });
            this.optimization = new OptimizationPane({
                    model: this.model,
                    name: "optimization",
                    location: "right"
                });

            this.registerAction(this.statistics.name, this.statistics);
            this.registerAction(this.optimization.name, this.optimization);

            this.swoshContainer = new SwoshContainer({
                model: this.model,
                swoshPanes: [{
                    intent: config.intents.view.statistics,
                    widget: this.statistics
                }, {
                    intent: config.intents.view.optimization,
                    widget: this.optimization
                }]
            });
            this.own(this.swoshContainer);

            this.currentAction = this.statistics.name;
            this.previousActionFallback = true;
        },

        takeAction: function(actions, params) {
            if (!actions || !actions.length) {
                return this.inherited(arguments);
            }
            var activePane = this.findActionable(actions[0]);
            
            for(var i in this.swoshContainer.swoshPanes) {
                var widget = this.swoshContainer.swoshPanes[i].widget;
                if (activePane == widget) {
                    this.swoshContainer.setActiveWidget(i);
                }
            }
            this.inherited(arguments);
            return activePane;
        },

        refresh: function() {
            this.statistics.refresh();
            this.optimization.refresh();
        },

        show: function() {
            this._setupView([this.swoshContainer]);
        }
    });
});
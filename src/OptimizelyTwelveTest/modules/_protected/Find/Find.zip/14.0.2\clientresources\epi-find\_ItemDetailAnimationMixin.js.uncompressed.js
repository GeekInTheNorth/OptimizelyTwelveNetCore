﻿define("epi-find/_ItemDetailAnimationMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/window",
    "dojo/Deferred",
    "dojo/dom-class",
    "dojo/dom-geometry",
    "dojo/dom-style",
    "dojo/dom-construct",

    "./Animator"
],

function (declare, lang, dojoWindow, Deferred, domClass, domGeom, domStyle, domConstruct, Animator
) {

    return declare([], {
        // summary: 
        //      Mixin to enable Detail widget animation in Controllers

        _scrollPosition: 0,
        _minimizedNodePosition: null,


        _getWidgetToAnimate: function(data) {
            // summary:
            //      Callback that inheritor can override. Should return a widget instance that is going to be animated.
            //  tags:
            //      protected
            var details = this.itemCarousel.details.current;
            details.set("requestExtraData", false); // disable any additional data requests during animation
            if (data){
                details.setCurrentItem(data);
            }
            return details;
        },

        _returnWidgetToAnimate: function(widget) {
            // summary:
            //      Callback that inheritor can override. Should return a widget instance that was animated to
            // its initial position in the DOM
            //  tags:
            //      protected

            // return animated node back to carousel
            domConstruct.place(widget.domNode, this.itemCarousel.details.previous.domNode, "after");
            widget.set("requestExtraData", true);
        },

        _getWidgetToAnimatePositions: function(rowElement) {
            // get positions of required nodes
            var parentPosition = domGeom.position(this.rootWidget.domNode, true);

            var toolbarPosition =  domGeom.position(this.toolBar.domNode, true);
            if (!toolbarPosition.h) { // if toolbar height is not known yet, add it to the DOM, measure and delete then
                domStyle.set(this.toolBar.domNode, "visibility", "hidden");
                this.rootWidget.addChild(this.toolBar);
                toolbarPosition =  domGeom.position(this.toolBar.domNode, true);
                this.rootWidget.removeChild(this.toolBar);
                domStyle.set(this.toolBar.domNode, "visibility", "visible");
            }

            // calculate absolute position of the clicked row
            if (rowElement) {
                var rowPosition = domGeom.position(rowElement, true);
                this._minimizedNodePosition = {
                    "left": (rowPosition.x - parentPosition.x) + "px",
                    "top": (rowPosition.y - parentPosition.y) + "px",

                    "width": rowPosition.w + "px",
                    "height": rowPosition.h + "px"
                };
            }

            var nodeMaximizedPosition = {
                "top": toolbarPosition.h + this._scrollPosition + "px",
                "height": parentPosition.h - toolbarPosition.h + "px",
                "left": parentPosition.x + "px",
                "width": parentPosition.w + "px"
            };

            return {minimized: this._minimizedNodePosition, maximized: nodeMaximizedPosition};
        },

        _showItemDetails: function (data, element) {
            //  summary:
            //      Animate expanding item row/card
            //  tags:
            //      protected
            var animationDeferred = new Deferred();
            if (Animator.isAnimationSupported()) {

                // save the scroll position
                this._scrollPosition = domGeom.docScroll().y;

                // fix body height
                var body = dojoWindow.body();
                domStyle.set(body, "height", "100%");

                // replace vertical scroll with negative margin-top so that
                // previous content (list) remains on the same position,
                // but the new content (details) is displayed without vertical scroll
                domStyle.set(body, "marginTop", -this._scrollPosition +"px");
                window.scrollTo(0, 0);

                // get a widget that is going to be animated
                var details = this._getWidgetToAnimate(data);

                var nodePositions = this._getWidgetToAnimatePositions(element);

                // set initial position for the animated node
                domStyle.set(details.domNode, nodePositions.minimized);

                // add CSS classes for the animated node
                domClass.add(details.domNode, "epi-itemList__item--clone");
                domClass.add(details.domNode, "epi-item-details-animate-scale");

                // add the animated widget to the DOM
                this.rootWidget.addChild(details);

                // animate
                var transition = Animator.transition([details.domNode]);
                transition.start.then(lang.hitch(this, function () {

                    // remove -init CSS class so that animated node start to scale up
                    domClass.remove(details.domNode, "epi-item-details-animate-scale");
                    details.set("requestExtraData", true);// TODO: Move this

                    // set animated node end position
                    domStyle.set(details.domNode, nodePositions.maximized);

                }));
                transition.end.then(lang.hitch(this, function () {
                    // remove margin-top
                    domStyle.set(body, "marginTop", "");

                    // correct animated node position
                    domStyle.set(details.domNode, "top", parseInt(domStyle.get(details.domNode, "top"), 10) - this._scrollPosition + "px");

                    // restore body height
                    domStyle.set(body, "height", "");

                    animationDeferred.resolve();
                }));

            } else {
                animationDeferred.resolve();
            }


            var results = {animationComplete: animationDeferred.promise, notifyLoadComplete: lang.hitch(this , function() {
                // notifyLoadComplete callback should be called when data load for details is complete
                this._returnWidgetToAnimate(details);
                // remove CSS classes previously added to the animated node
                domClass.remove(details.domNode, "epi-itemList__item--clone");

            })};

            return results;
        },

        _hideItemDetails: function () {
            //  summary:
            //      Animate collapsing details item
            //  tags:
            //      protected

            // Animate collapsing item row/card
            var animationDeferred = new Deferred();
            if (Animator.isAnimationSupported()) {

                var body = dojoWindow.body();

                // fix body height
                domStyle.set(body, "height", "100%");

                // reset scroll and set negative margin top to the saved scroll position
                window.scrollTo(0, 0);
                domStyle.set(body, "marginTop", -this._scrollPosition  +"px");

                // get a widget that is going to be animated
                var details = this._getWidgetToAnimate();

                // mark widget as animated so it will not be deleted when _setupView is called
                this.widgetsInAnimation.push(details);

                var nodePositions = this._getWidgetToAnimatePositions();
                // set initial position of the animated node
                domStyle.set(details.domNode, nodePositions.maximized);

                // add CSS classes for the animated node
                domClass.add(details.domNode, "epi-itemList__item--clone");

                // place the animated widget node to a new position in the DOM
                this.rootWidget.addChild(details);

                // animate
                var transition = Animator.transition([details.domNode]);
                transition.start.then(lang.hitch(this, function () {
                    // if there is a saved position - set it as target end position
                    if (nodePositions.minimized) {
                        domStyle.set(details.domNode, nodePositions.minimized);
                    }
                    // add CSS class that produces animation effect opposite to one that is used in _showItemDetails
                    domClass.add(details.domNode, "epi-item-details-animate-scale");

                }));
                transition.end.then(lang.hitch(this, function () {
                    // restore body height
                    domStyle.set(body, "height", "");

                    // restore scroll position
                    domStyle.set(body, "marginTop", "");
                    window.scrollTo(0, this._scrollPosition);

                    // remove CSS class used for animation
                    domClass.remove(details.domNode, "epi-item-details-animate-scale");
                    domClass.remove(details.domNode, "epi-itemList__item--clone");

                    this._returnWidgetToAnimate(details);

                    // clean root widgets content
                    this._removeWidgetsInAnimation();

                    animationDeferred.resolve();
                }));

            } else {
                animationDeferred.resolve();
            }

            return animationDeferred.promise;

        }

    });
});
